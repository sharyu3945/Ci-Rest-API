<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MyModel extends CI_Model {

    var $client_service = "frontend-client";
    var $auth_key       = "shopping-restapi";

    public function check_auth_client(){
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key  = $this->input->get_request_header('Auth-Key', TRUE);
        if($client_service == $this->client_service && $auth_key == $this->auth_key){
            return true;
        } else {
            return json_output(401,array('status' => 401,'message' => 'Unauthorized.'));
        }
    }

    public function login($username,$password)
    {
        $q  = $this->db->select('password,id')->from('users')->where('username',$username)->get()->row();
      
        if($q == ""){
            return array('status' => 204,'message' => 'Username not found.');
        } else {
            $hashed_password = $q->password;
            $id              = $q->id;
            if (md5($password) == $hashed_password) {
               $last_login = date('Y-m-d H:i:s');
               $token = md5(rand());
               $expired_at = date("Y-m-d H:i:s", strtotime('+12 hours'));
               $this->db->trans_start();
               $this->db->where('id',$id)->update('users',array('last_login' => $last_login));
               $this->db->insert('users_authentication',array('users_id' => $id,'token' => $token,'expired_at' => $expired_at));
               if ($this->db->trans_status() === FALSE){
                  $this->db->trans_rollback();
                  return array('status' => 500,'message' => 'Internal server error.');
               } else {
                  $this->db->trans_commit();
                  return array('status' => 200,'message' => 'Successfully login.','id' => $id, 'token' => $token);
               }
            } else {
               return array('status' => 204,'message' => 'Wrong password.');
            }
        }
    }

    public function logout()
    {
        $users_id  = $this->input->get_request_header('User-ID', TRUE);
        $token     = $this->input->get_request_header('Authorization', TRUE);
        $this->db->where('users_id',$users_id)->where('token',$token)->delete('users_authentication');
        return array('status' => 200,'message' => 'Successfully logout.');
    }

    public function auth()
    {
        $users_id  = $this->input->get_request_header('User-ID', TRUE);
        $token     = $this->input->get_request_header('Authorization', TRUE);
        $q  = $this->db->select('expired_at')->from('users_authentication')->where('users_id',$users_id)->where('token',$token)->get()->row();
        if($q == ""){
            return array('status' => 401,'message' => 'Unauthorized.');
        } else {
            if($q->expired_at < date('Y-m-d H:i:s')){
                return array('status' => 401,'message' => 'Your session has been expired.');
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = date("Y-m-d H:i:s", strtotime('+12 hours'));
                $this->db->where('users_id',$users_id)->where('token',$token)->update('users_authentication',array('expired_at' => $expired_at,'updated_at' => $updated_at));
                return array('status' => 200,'message' => 'Authorized.');
            }
        }
    }
    public function product_update_data($id,$data)
    {
        $this->db->where('p_id',$id)->update('tbl_products',$data);
        return array('status' => 200,'message' => 'Data has been updated.');
    }

    public function product_delete_data($id)
    {
        $this->db->where('p_id',$id)->delete('tbl_products');
        return array('status' => 200,'message' => 'Data has been deleted.');
    }

    /* Products */

    public function saveProductsData($data='')
    {
        $insertArr = array(
                        'title'         => $data['title'],
                        'description'   => $data['description'], 
                        'quantity'      => $data['quantity'], 
                        'price'         => $data['price']
                );
        if($this->db->insert("tbl_products",$insertArr)){
            return array('status' => 201,'message' => 'Products has been added.');
        }
        
    }

    public function saveOrderData($data='')
    {
        $checkCustomerExists = $this->customerDetails($data['contact_no'],$data['email']);
        
        if($checkCustomerExists!= 400 &&  !empty($checkCustomerExists)){
            $customer_id = $checkCustomerExists['customer_id'];
        }
        else{
            $custArr = array(
                            'first_name'    => $data['first_name'],
                            'last_name'     => $data['last_name'],
                            'email'         => $data['email'],
                            'contact_no'    => $data['contact_no'],
                        );
            $this->db->insert("tbl_customer",$custArr);
            $customer_id = $this->db->insert_id();
        }
        $insertArr = array(
                    'customer_id'   => $customer_id, 
                    'first_name'    => $data['first_name'], 
                    'last_name'     => $data['last_name'], 
                    'email'         => $data['email'], 
                    'contact'       => $data['contact_no'], 
                    'address1'      => $data['address1'], 
                    'address2'      => $data['address2'], 
                    'pincode'       => $data['pincode'], 
                    'subtotal'      => $data['subtotal'], 
                    'total_qty'     => $data['total_qty'], 
                    'total_amount'  => $data['total_amount'], 
                    'order_status'  => 'confirmed'
                );
        $flag = 0; 
        if($this->db->insert("tbl_orders",$insertArr)){
            $order_id =$this->db->insert_id();
            $i = 0;
            foreach ($data['orderProduct'] as $productValue) {
                $totArr = array(
                             'order_id'     => $order_id, 
                             'product_id'   => $productValue['product_id'], 
                             'title'        => $productValue['title'], 
                             'price'        => $productValue['price'], 
                             'qty'          => $productValue['qty'], 
                             'total_price'  => $productValue['total_price'], 
                        );
                if($this->db->insert("tbl_order_products",$totArr)){
                    $query  = $this->db->query("SELECT quantity FROM tbl_products WHERE p_id ='".$productValue['product_id']."'");
                    $result = $query->row_array();
                    $qty = $result['quantity']-1;
                    $this->db->where('p_id',$productValue['product_id'])->update('tbl_products',array('quantity'=>$qty));
                    $flag = 1;
                }
                $i++;
                $flag = 1;
            }
            if($flag == 1){
                return array('status' => 201,'message' => 'Order has been created.');
            }
            else{
                return array('status' => 400,'message' => 'Failed to create order.');   
            }
            
        }
        
    }

    function customerDetails($contact_no,$email){
        if($contact_no!=""){
            $query = $this->db->query("SELECT * FROM tbl_customer WHERE contact_no ='".$contact_no."'");
            return $query->row_array();
        }
        elseif ($email!="") {
            $query = $this->db->query("SELECT * FROM tbl_customer WHERE email ='".$email."'");
            return $query->row_array();
        }
        else{
            return 400;
        }   
    }

    function getOrderDetails($data){
        $orderQuery = $this->db->query("SELECT * FROM tbl_orders WHERE order_id ='".$data['order_id']."'");
        $result = $orderQuery->row_array();

        if(isset($result) && !empty($result)){
            $orderQuery = $this->db->query("SELECT * FROM tbl_order_products WHERE order_id ='".$data['order_id']."'");
            $productResult = $orderQuery->result_array();


            $resultArr = array(
                            'order_id'      => $result['order_id'], 
                            'customer_id'   => $result['customer_id'], 
                            'first_name'    => $result['first_name'], 
                            'last_name'     => $result['last_name'], 
                            'email'         => $result['email'], 
                            'contact'       => $result['contact'], 
                            'address1'      => $result['address1'], 
                            'address2'      => $result['address2'], 
                            'pincode'       => $result['pincode'], 
                            'subtotal'      => $result['subtotal'], 
                            'total_qty'     => $result['total_qty'], 
                            'total_amount'  => $result['total_amount'], 
                            'order_status'  => $result['order_status'], 
                            'added_date'    => $result['added_date'], 
                            'updated_date'  => $result['updated_date'],
                            'productData'   => $productResult
                        );
            return $resultArr;
        }   
        else{
            return 400;
        }
    }

    function changeOrderStatus($data){
        $orderQuery = $this->db->query("SELECT * FROM tbl_orders WHERE order_id ='".$data['order_id']."'");
        $result = $orderQuery->row_array();

        if(isset($result) && !empty($result)){
            $this->db->where('order_id',$data['order_id'])->update('tbl_orders',array('order_status'=>$data['order_status']));
            return 200;
        }   
        else{
            return 400;
        }
    }
}
