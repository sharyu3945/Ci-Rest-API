<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
    }


	public function saveOrderData()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true){
		        $params = json_decode(file_get_contents('php://input'), TRUE);
		        if ($params['contact_no'] == "" || $params['email'] == "" || $params['total_amount']=="") {
					$respStatus = 400;
					$resp = array('status' => 400,'message' =>  'Conatct number, Email, Prducts required');
					json_output($respStatus,$resp);
				} else {
	        		$resp = $this->MyModel->saveOrderData($params);
	        		json_output(200,$resp);
				}
				
			}
		}
	}

	public function getOrderDetails()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true){
		        $params = json_decode(file_get_contents('php://input'), TRUE);
				if ($params['order_id'] == "") {
					$respStatus = 400;
					$resp = array('status' => 400,'message' =>  'Order Id required');
					json_output($respStatus,$resp);
				} else {
	        		$resp = $this->MyModel->getOrderDetails($params);
	        		if($resp != 400){
	        			json_output(200,$resp);	
	        		}
	        		else{
	        			$resp = array('status' => 400,'message' =>  'Failed to get details');
	        			$resp = json_output("400",$resp);
	        			return $resp;
	        		}
	        		
				}
				
			}
		}
	}

	public function changeOrderStatus()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true){
				$response 	= $this->MyModel->auth();
				$respStatus = $response['status'];

				if($response['status'] == 200){
					$params = json_decode(file_get_contents('php://input'), TRUE);
					if ($params['order_id'] == "") {
						$respStatus = 400;
						$resp = array('status' => 400,'message' =>  'Order Id required');
						json_output($respStatus,$resp);
					} else {
		        		$resp = $this->MyModel->changeOrderStatus($params);
		        		if($resp != 400){
		        			json_output(200,array('status' => 200,'message' =>  'Change order status'));	
		        		}
		        		else{
		        			$resp = array('status' => 400,'message' =>  'Failed to get details');
		        			$resp = json_output("400",$resp);
		        			return $resp;
		        		}
					}
				}
			}
		}
	}

}
